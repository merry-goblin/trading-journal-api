<?php

namespace App\Domain\Service\Screenshot;

use App\DTO\Screenshot\ScreenshotInput;
use App\Entity\Screenshot;

use SplFileObject;

interface ScreenshotServiceInterface
{
    public function list(): array;

    public function get(int $id): ?Screenshot;

    public function create(ScreenshotInput $input): Screenshot;
}
